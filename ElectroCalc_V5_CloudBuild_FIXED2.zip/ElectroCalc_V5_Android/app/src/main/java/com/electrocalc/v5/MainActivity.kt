package com.electrocalc.v5

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import kotlin.math.*

class MainActivity : Activity() {
    data class Tool(val name: String, val group: String, val fields: List<String>, val hint: String = "")
    private lateinit var container: LinearLayout
    private lateinit var spinner: Spinner
    private lateinit var inputBox: LinearLayout
    private lateinit var result: TextView
    private val inputs = mutableListOf<EditText>()
    private lateinit var tools: List<Tool>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,42,67)
        window.navigationBarColor = Color.rgb(16,42,67)
        tools = buildTools()
        val scroll = ScrollView(this)
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 28)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.rgb(244,247,251))
        }
        scroll.addView(container)
        setContentView(scroll)

        addText("الکترونیک‌یار ۵", 26, true, "#102A43")
        addText("ماشین‌حساب و ابزارهای تعمیرات الکترونیک — آفلاین", 14, false, "#526579")
        addText("انتخاب ابزار", 16, true, "#102A43")
        spinner = Spinner(this)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, tools.map { "${it.group}  |  ${it.name}" })
        spinner.adapter = adapter
        container.addView(spinner, matchWrap())
        inputBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        container.addView(inputBox)
        val calc = Button(this).apply {
            text = "محاسبه"
            textSize = 17f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(21,101,192))
        }
        container.addView(calc, matchWrap())
        result = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.rgb(16,42,67))
            setPadding(16,18,16,18)
            setBackgroundColor(Color.WHITE)
            text = "نتیجه محاسبه اینجا نمایش داده می‌شود."
        }
        val lp = matchWrap()
        lp.topMargin = 16
        container.addView(result, lp)
        val note = TextView(this).apply {
            text = "توجه: نتایج تقریبی و آموزشی‌اند. برای مدارهای برق شهر، UPS و منابع تغذیه ولتاژ بالا، قبل از هر اقدام ایمنی و دیتاشیت قطعات را بررسی کنید."
            textSize = 12f
            setTextColor(Color.rgb(160,65,30))
            setPadding(8,18,8,8)
        }
        container.addView(note)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { makeInputs(position) }
        }
        calc.setOnClickListener { calculate(spinner.selectedItemPosition) }
        makeInputs(0)
    }

    private fun buildTools() = listOf(
        Tool("قانون اهم و توان","پایه", listOf("ولتاژ V","جریان A")),
        Tool("مقاومت سری","پایه", listOf("مقاومت اول Ω","مقاومت دوم Ω","مقاومت سوم Ω")),
        Tool("مقاومت موازی","پایه", listOf("مقاومت اول Ω","مقاومت دوم Ω")),
        Tool("انرژی و زمان باتری","باتری", listOf("ولتاژ باتری V","ظرفیت Ah","توان مصرفی W")),
        Tool("مقاومت سری LED","قطعات", listOf("ولتاژ منبع V","ولتاژ LED V","جریان LED mA")),
        Tool("تقسیم ولتاژ","پایه", listOf("ولتاژ ورودی V","R بالا Ω","R پایین Ω")),
        Tool("فرکانس و پریود","سیگنال", listOf("فرکانس Hz")),
        Tool("ثابت زمانی RC","سیگنال", listOf("مقاومت kΩ","خازن µF")),
        Tool("راکتانس خازن","سیگنال", listOf("فرکانس Hz","خازن µF")),
        Tool("راکتانس سلف","سیگنال", listOf("فرکانس Hz","سلف mH")),
        Tool("ترانسفورماتور ایده‌آل","منابع تغذیه", listOf("ولتاژ اولیه V","ولتاژ ثانویه V","تعداد دور اولیه")),
        Tool("راندمان و تلفات","منابع تغذیه", listOf("توان ورودی W","توان خروجی W")),
        Tool("افت ولتاژ سیم مسی DC","سیم‌کشی", listOf("جریان A","طول یک‌طرفه m","سطح مقطع mm²")),
        Tool("کد رنگ مقاومت ۴ نواره","قطعات", listOf("نوار اول 0 تا 9","نوار دوم 0 تا 9","ضریب 10 به توان","تلرانس درصد")),
        Tool("تلفات روشن MOSFET","قطعات", listOf("جریان A","Rds(on) بر حسب mΩ")),
        Tool("ولتاژ DC پل دیود","منابع تغذیه", listOf("ولتاژ AC RMS","افت هر دیود V")),
        Tool("گرمای رگولاتور 7805","منابع تغذیه", listOf("ولتاژ ورودی V","جریان بار A")),
        Tool("مقاومت تنظیم LM317","منابع تغذیه", listOf("ولتاژ خروجی V","مقاومت R1 Ω (معمولاً 240)")),
        Tool("دیوتی سایکل باک","منابع تغذیه", listOf("ولتاژ ورودی V","ولتاژ خروجی V")),
        Tool("دیوتی سایکل بوست","منابع تغذیه", listOf("ولتاژ ورودی V","ولتاژ خروجی V")),
        Tool("تقسیم مقاومتی TL431","منابع تغذیه", listOf("ولتاژ خروجی هدف V","مقاومت پایین Ω")),
        Tool("مقاومت LED اپتوکوپلر","منابع تغذیه", listOf("ولتاژ تحریک V","افت LED اپتو V","جریان LED mA")),
        Tool("مقاومت سری زنر","قطعات", listOf("ولتاژ ورودی V","ولتاژ زنر V","جریان بار mA","جریان زنر پیشنهادی mA")),
        Tool("ترانزیستور BJT","قطعات", listOf("ولتاژ تغذیه V","جریان کلکتور mA","بتای اجباری")),
        Tool("خازن صافی","منابع تغذیه", listOf("جریان بار A","فرکانس ریپل Hz","ریپل مجاز V")),
        Tool("نوسان‌ساز 555","سیگنال", listOf("R1 kΩ","R2 kΩ","C µF")),
        Tool("جریان شارژ باتری UPS","UPS", listOf("ظرفیت باتری Ah","جریان شارژ A")),
        Tool("اتصال موازی MOSFETها","UPS", listOf("جریان کل A","تعداد MOSFET","Rds هر قطعه mΩ")),
        Tool("ترانس اینورتر (نسبت دور)","UPS", listOf("ولتاژ DC ورودی V","ولتاژ AC هدف RMS V","تعداد دور اولیه")),
        Tool("افت ولتاژ باتری زیر بار","UPS", listOf("ولتاژ بی‌باری V","ولتاژ زیر بار V","جریان بار A")),
        Tool("جریان بی‌باری و راندمان UPS","UPS", listOf("ولتاژ باتری V","جریان بی‌باری A","توان خروجی W"))
    )

    private fun makeInputs(index: Int) {
        inputs.clear(); inputBox.removeAllViews()
        val tool = tools[index]
        addTo(inputBox, tool.hint.ifBlank { "مقادیر را با واحد نوشته‌شده وارد کنید." }, 13, false, "#526579")
        tool.fields.forEach { label ->
            val e = EditText(this).apply {
                hint = label
                textSize = 15f
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL or android.text.InputType.TYPE_NUMBER_FLAG_SIGNED
                setSingleLine(true)
                layoutDirection = View.LAYOUT_DIRECTION_LTR
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                setPadding(12,10,12,10)
                setBackgroundColor(Color.WHITE)
            }
            val p = matchWrap(); p.topMargin = 7; p.bottomMargin = 5
            inputBox.addView(e,p); inputs.add(e)
        }
        result.text = "ابزار: ${tool.name}\nورودی‌ها را تکمیل و محاسبه را لمس کنید."
    }

    private fun calculate(i: Int) {
        val v = inputs.map { it.text.toString().trim().replace(',', '.').toDoubleOrNull() ?: Double.NaN }
        if (v.any { it.isNaN() }) { result.text = "لطفاً همه ورودی‌ها را با عدد معتبر تکمیل کنید."; return }
        fun out(s: String) { result.text = s }
        fun f(x: Double) = if (x.isFinite()) String.format("%.4g", x) else "نامعتبر"
        try {
            val s = when(i) {
                0 -> "مقاومت معادل: ${f(v[0]/v[1])} Ω\nتوان: ${f(v[0]*v[1])} W"
                1 -> "مقاومت کل: ${f(v.sum())} Ω"
                2 -> "مقاومت معادل: ${f(1.0/(1.0/v[0]+1.0/v[1]))} Ω"
                3 -> { val wh=v[0]*v[1]; "انرژی اسمی: ${f(wh)} Wh\nزمان تقریبی: ${f(wh/v[2])} ساعت\n(بدون لحاظ راندمان و افت ظرفیت)" }
                4 -> "مقاومت سری: ${f((v[0]-v[1])/(v[2]/1000.0))} Ω"
                5 -> "ولتاژ خروجی: ${f(v[0]*v[2]/(v[1]+v[2]))} V"
                6 -> "پریود: ${f(1/v[0])} ثانیه"
                7 -> "ثابت زمانی: ${f(v[0]*v[1]/1000.0)} میلی‌ثانیه\n(τ = R × C)"
                8 -> "راکتانس خازنی: ${f(1/(2*PI*v[0]*v[1]*1e-6))} Ω"
                9 -> "راکتانس سلفی: ${f(2*PI*v[0]*v[1]/1000.0)} Ω"
                10 -> "ولتاژ ثانویه: ${f(v[1])} V\nتعداد دور ثانویه: ${f(v[2]*v[1]/v[0])} دور"
                11 -> "راندمان: ${f(v[1]/v[0]*100)} %\nتلفات: ${f(v[0]-v[1])} W"
                12 -> { val drop=2*0.0175*v[0]*v[1]/v[2]; "افت ولتاژ: ${f(drop)} V\nافت درصدی نسبت به 12V: ${f(drop/12*100)} %" }
                13 -> { val digits=v[0]*10+v[1]; val ohm=digits*10.0.pow(v[2]); "مقدار مقاومت: ${f(ohm)} Ω\nتلرانس: ±${f(v[3])} %" }
                14 -> "تلفات هدایت تقریبی: ${f(v[0]*v[0]*v[1]/1000)} W"
                15 -> "ولتاژ DC پیک تقریبی: ${f(v[0]*sqrt(2.0)-2.0*v[1])} V"
                16 -> { val p=(v[0]-5)*v[1]; "تلفات حرارتی: ${f(p)} W\nدمای هیت‌سینک و محدودیت حرارتی را بررسی کنید." }
                17 -> "مقاومت تنظیم تقریبی: ${f((v[0]-1.25)/0.005)} Ω\n(با فرض جریان ADJ ناچیز)"
                18 -> "دیوتی سایکل ایده‌آل Buck: ${f(v[1]/v[0]*100)} %"
                19 -> "دیوتی سایکل ایده‌آل Boost: ${f((1-v[0]/v[1])*100)} %"
                20 -> "مقاومت بالای TL431: ${f(v[1]*(v[0]/2.495-1))} Ω\n(مرجع تقریبی 2.495V)"
                21 -> "مقاومت سری LED اپتو: ${f((v[0]-v[1])/(v[2]/1000))} Ω"
                22 -> { val total=(v[2]+v[3]); "مقاومت سری: ${f((v[0]-v[1])/(total/1000))} Ω\nتوان زنر: ${f(v[1]*v[3]/1000)} W" }
                23 -> { val ic=v[1]/1000; "جریان پایه پیشنهادی: ${f(ic/v[2]*1000)} mA\nتوان تقریبی کلکتور (تقریب): ${f(v[0]*ic)} W" }
                24 -> "ظرفیت صافی تقریبی: ${f(v[0]/(v[1]*v[2])*1e6)} µF"
                25 -> { val t1=0.693*(v[0]+v[1])*1000*v[2]*1e-6; val t2=0.693*v[1]*1000*v[2]*1e-6; "فرکانس: ${f(1/(t1+t2))} Hz\nزمان High: ${f(t1*1000)} ms\nزمان Low: ${f(t2*1000)} ms\nDuty: ${f(t1/(t1+t2)*100)} %" }
                26 -> "جریان شارژ: ${f(v[1])} A\nنرخ شارژ: ${f(v[1]/v[0])} C\nزمان نظری: ${f(v[0]/v[1])} ساعت\n(پروفایل شارژ و شیمی باتری مهم است)"
                27 -> { val each=v[0]/v[1]; val loss=each*each*v[2]/1000; "جریان هر MOSFET: ${f(each)} A\nتلفات هر قطعه: ${f(loss)} W\nتقسیم جریان واقعی به چیدمان و دما وابسته است." }
                28 -> "نسبت دور تقریبی: ${f(v[1]/v[0])}\nدور ثانویه ایده‌آل: ${f(v[2]*v[1]/v[0])}\n(موج مربعی/شبه‌سینوسی و توپولوژی باید لحاظ شود)"
                29 -> { val r=(v[0]-v[1])/v[2]; "مقاومت داخلی/مسیر معادل: ${f(r)} Ω\nافت ولتاژ: ${f(v[0]-v[1])} V" }
                30 -> { val pin=v[0]*v[1]; "توان ورودی بی‌باری: ${f(pin)} W\nراندمان در بار اعلام‌شده: ${f(v[2]/(pin+v[2])*100)} % (تقریبی)" }
                else -> "ابزار ناشناخته"
            }
            out(s)
        } catch (e: Exception) { out("خطا در محاسبه. ورودی‌ها را بررسی کنید.") }
    }

    private fun addText(text: String, size: Int, bold: Boolean, color: String) = addTo(container,text,size,bold,color)
    private fun addTo(parent: LinearLayout, text: String, size: Int, bold: Boolean, color: String) {
        val tv=TextView(this).apply {
            this.text=text; textSize=size.toFloat(); setTextColor(Color.parseColor(color))
            if(bold) setTypeface(null, Typeface.BOLD)
            gravity=Gravity.RIGHT; setPadding(4,8,4,8)
        }
        parent.addView(tv,matchWrap())
    }
    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
}
