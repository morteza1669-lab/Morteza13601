الکترونیک‌یار نسخه ۵ — پروژه Native اندروید

این پروژه یک اپلیکیشن واقعی اندروید با Kotlin و Android Views است؛ از WebView یا HTML استفاده نمی‌کند.
قابلیت‌ها:
- ابزارهای پایه، قطعات، سیگنال، منابع تغذیه و سیم‌کشی
- ابزارهای تخصصی UPS
- رابط فارسی و راست‌چین
- بدون نیاز به اینترنت هنگام اجرای برنامه

ساخت APK بدون نصب Android Studio (با GitHub Actions):
1) وارد github.com شوید و یک حساب GitHub داشته باشید.
2) یک مخزن جدید (New repository) بسازید. بهتر است Private باشد.
3) محتویات پوشه ElectroCalc_V5_Android را در مخزن بارگذاری کنید؛ دقت کنید پوشه .github هم بارگذاری شود.
4) در GitHub وارد بخش Actions مخزن شوید.
5) اگر اجرای Workflow غیرفعال است، گزینه I understand my workflows, go ahead and enable them را بزنید.
6) در فهرست سمت چپ Build Android APK را انتخاب و Run workflow را اجرا کنید؛ یا پس از push روی شاخه main، ساخت خودکار شروع می‌شود.
7) پس از پایان موفق، وارد اجرای انجام‌شده شوید. در بخش Artifacts فایل ElectroCalc-V5-debug-APK را دانلود کنید.
8) ZIP دانلودشده را باز کنید و فایل app-debug.apk را روی گوشی نصب کنید. ممکن است اندروید برای نصب از منبع ناشناس اجازه بخواهد.

ساخت با Android Studio:
1) فایل ZIP را استخراج کنید.
2) پوشه ElectroCalc_V5_Android را با Android Studio باز کنید.
3) از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) استفاده کنید.
4) APK خروجی معمولاً در app/build/outputs/apk/debug/app-debug.apk قرار می‌گیرد.

حداقل Android: 6.0 (API 23)
Compile/Target SDK: 35
ساخت ابری توسط فایل .github/workflows/build-apk.yml تنظیم شده است.
برای ساخت ابری، GitHub به اینترنت نیاز دارد و فایل APK به‌صورت Artifact در همان مخزن در دسترس خواهد بود.

نکته:
این ZIP پروژه و تنظیمات ساخت خودکار است، نه APK کامپایل‌شده. محاسبات آموزشی و تقریبی‌اند و برای تعمیر UPS یا مدارهای برق شهر، جایگزین دیتاشیت، اندازه‌گیری ایمن و بررسی مهندسی نیستند.
