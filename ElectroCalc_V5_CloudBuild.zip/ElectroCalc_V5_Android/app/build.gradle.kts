plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.electrocalc.v5"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.electrocalc.v5"
        minSdk = 23
        targetSdk = 35
        versionCode = 5
        versionName = "5.0"
    }
}
